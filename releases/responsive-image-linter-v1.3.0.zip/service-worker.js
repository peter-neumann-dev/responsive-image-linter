function i() {
  if (window.respImageLintCollectorRunning) {
    console.warn("RespImageLint collector already initialized!");
    return;
  }
  window.respImageLintCollectorRunning = !0, console.log("RespImageLint collector initialized!");
  const e = document.createElement("script");
  e.src = chrome.runtime.getURL("collector.js"), e.type = "text/javascript", e.onerror = () => {
    console.error("Failed to load collector script"), window.respImageLintCollectorRunning = !1;
  }, (document.head || document.documentElement).appendChild(e), e.onload = () => e.remove();
}
async function n(e, t) {
  const o = [
    "X-Frame-Options",
    "Frame-Options",
    "Content-Security-Policy"
  ];
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1],
    addRules: [
      {
        id: 1,
        action: {
          type: chrome.declarativeNetRequest.RuleActionType.MODIFY_HEADERS,
          responseHeaders: o.map((r) => ({
            header: r,
            operation: chrome.declarativeNetRequest.HeaderOperation.REMOVE
          }))
        },
        condition: {
          requestDomains: [t],
          resourceTypes: [chrome.declarativeNetRequest.ResourceType.SUB_FRAME],
          tabIds: [e]
        }
      }
    ]
  }), await chrome.browsingData.remove(
    { origins: [`https://${t}`] },
    { cacheStorage: !0, serviceWorkers: !0 }
  );
}
chrome.action.onClicked.addListener(async (e) => {
  if (!e.url || !e.id) {
    console.error("Invalid tab information");
    return;
  }
  const t = new URL(e.url).hostname;
  try {
    await n(e.id, t), await chrome.scripting.executeScript({
      target: { tabId: e.id },
      func: i
    }), console.log("Extension initialized successfully");
  } catch (o) {
    console.error("Extension initialization failed:", o);
  }
});
